# Canvas-CrossLister
A web application that allows  ITS staff to cross-list multiple courses at once. 

Built using 

- Python
- CanvasAPI 
